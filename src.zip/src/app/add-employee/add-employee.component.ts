import { Component, OnInit } from '@angular/core';
import employeedata from '../../data/employeedata.json';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employees=employeedata;

  constructor() { 
    
  }

  ngOnInit() {
  }
  /*addEmployee(add)
  {
    console.log("Before Adding:",add.id,add.salary)
   this.employees.push(add);
 }*/

 addEmployee(add)
    {
        this.employees.push({
          empId:add.empId,
          empName:add.empName,
          empSal:add.empSal,
          empDep:add.empDep

        });
    }
}
