import { Component, OnInit } from '@angular/core';
import { UpdateEmployeeService } from '../update-employee.service';
import employeedata from '../../data/employeedata.json'
@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  array=employeedata
  emp:any
  empId:any
  empName:any
  empSal:any
  empDep:any
  index=null;

 constructor(private service: UpdateEmployeeService) { }

 ngOnInit() {
    if(this.service.subsVar==undefined)
    {
      this.service.subsVar=this.service.invokeupdate.subscribe((i:number) => { this.view(i)
     });
    }
 }
 view(i:number)
 {
   this.empId=this.array[i].empId
   this.empName=this.array[i].empName
   this.empSal=this.array[i].empSal
   this.empDep=this.array[i].empDep
   this.index=i
 }
 updateEmployee(form)
 {
   this.array.splice(this.index,1,{
     empId:this.empId,
     empName:this.empName,
     empSal:this.empSal,
     empDep:this.empDep
   })
 }


}
